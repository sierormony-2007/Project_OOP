/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class Cashier implements Istaff {
    private String id;
    private String name;
    private String position;

    public boolean can(String action) {

        return action.equals(CinemaSystem.SELL_TICKET)
                || action.equals(CinemaSystem.VIEW_MOVIES);
    }

    public Cashier(String id, String name) {
        this.id = id;
        this.name = name;
        this.position = "Cashier";
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPosition() {
        return position;
    }

    @Override
    public boolean can(String action) {
        // Cashiers can only perform "sell tickets" action
        return action.equalsIgnoreCase("sell tickets");
    }

}
