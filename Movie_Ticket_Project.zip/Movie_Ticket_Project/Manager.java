/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class Manager implements Istaff {
    private String id;
    private String name;
    private String position;

    public Manager(String id, String name) {
        this.id = id;
        this.name = name;
        this.position = "Manager";
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPosition() {
        return position;
    }

    @Override
    public boolean can(String action) {
        // Managers can perform all actions
        return true;
    }

}
